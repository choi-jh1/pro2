package com.ex.data;

import lombok.Data;

@Data
public class ReactionCountDTO {
    private String emotionType;
    private int count;
}
