package com.ex.data;

import lombok.Data;

@Data
public class SportsCateDTO {
	private int cateId;
	private String name;
}
