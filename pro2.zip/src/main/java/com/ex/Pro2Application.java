package com.ex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pro2Application {

	public static void main(String[] args) {
		SpringApplication.run(Pro2Application.class, args);
	}

}
